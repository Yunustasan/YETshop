import React from 'react'

export default function About() {
  return (
    <>
    
    <h1>Hakkımda</h1>
    17 yaşındayım,bilgisayar vb. teknolojik aletlere ilgim var.Arduino,Yazılım ve Yapay Zeka gibi alanlara ilgim var şu anda lisede okumaktayım ve kendimi geliştirme sürecindeyim.
    
    </>
  )
}