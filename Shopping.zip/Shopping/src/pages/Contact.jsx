import React from 'react'

export default function Contact() {
  return (
    
    <>
    
    <h1>İletişim</h1>
    <a href="https://www.linkedin.com/in/yunus-emre-ta%C5%9Fan-50a237295/">Linkdln</a>
    <a href="https://github.com/Yunustasan">github</a>
    
    </>
  )
}